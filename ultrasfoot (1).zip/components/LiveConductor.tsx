
import React, { useState, useEffect, useRef } from 'react';
import { SyncSignal, Team } from '../types';
import { CAF_COLORS } from '../constants';

interface LiveConductorProps {
  selectedTeam: Team;
  externalSignal?: SyncSignal | null;
}

const LiveConductor: React.FC<LiveConductorProps> = ({ selectedTeam, externalSignal }) => {
  const [matchMinute, setMatchMinute] = useState(0);
  const [activeSignal, setActiveSignal] = useState<SyncSignal | null>(null);
  const [countdown, setCountdown] = useState<number | null>(null);
  const [clappingStep, setClappingStep] = useState<number>(0);
  const [jumpStep, setJumpStep] = useState<number>(0);
  const [flashActive, setFlashActive] = useState(false);
  const [activeLyricsIndex, setActiveLyricsIndex] = useState(0);
  
  const countdownIntervalRef = useRef<number | null>(null);

  useEffect(() => {
    const timer = setInterval(() => {
      setMatchMinute(prev => {
        const next = prev < 90 ? prev + 1 : 0;
        if (selectedTeam.id === 'morocco') {
          if (next === 0) triggerPrep('ANTHEM', 'HYMNE NATIONAL');
          if (next > 0 && next % 10 === 0) triggerPrep('SONG', 'SIR! SIR! SIR!', 'ma_sir');
          if (next === 12) triggerPrep('SONG', 'AL HKAYA (MEXICO/QATAR)', 'ma_hkayat');
          if (next === 20) triggerPrep('JUMP', 'TOUT LE MONDE SAUTE !', 'ma_ole');
        }
        return next;
      });
    }, 15000); // Demo mode: 1 min = 15s
    return () => clearInterval(timer);
  }, [selectedTeam.id]);

  useEffect(() => {
    if (externalSignal) {
      triggerPrep(externalSignal.type, externalSignal.message, externalSignal.songId);
    }
  }, [externalSignal]);

  const triggerPrep = (type: SyncSignal['type'], message: string, songId?: string) => {
    setCountdown(5);
    setActiveSignal({ id: 'temp', timestamp: Date.now(), type, message, songId });
    
    if (countdownIntervalRef.current) window.clearInterval(countdownIntervalRef.current);
    countdownIntervalRef.current = window.setInterval(() => {
      setCountdown(prev => {
        if (prev && prev > 1) {
          if ('vibrate' in navigator) navigator.vibrate(100);
          return prev - 1;
        }
        window.clearInterval(countdownIntervalRef.current!);
        executeSignalNow(type, message, songId);
        return null;
      });
    }, 1000);
  };

  const executeSignalNow = (type: SyncSignal['type'], message: string, songId?: string) => {
    setFlashActive(true);
    setTimeout(() => setFlashActive(false), 500);

    if (type === 'JUMP') {
      runJumpSequence();
    } else if (type === 'CLAPPING') {
      runClappingSequence();
    } else if (type === 'SONG' || type === 'ANTHEM') {
      const song = selectedTeam.songs.find(s => s.id === songId) || selectedTeam.songs[0];
      setActiveLyricsIndex(0);
      const lyricsInterval = setInterval(() => {
        setActiveLyricsIndex(prev => {
          const totalLyrics = (type === 'ANTHEM' ? selectedTeam.anthemLyrics : (song?.lyrics || [])).length;
          return prev < totalLyrics - 1 ? prev + 1 : prev;
        });
      }, 4000);
      setTimeout(() => {
        clearInterval(lyricsInterval);
        setActiveSignal(null);
      }, 25000);
    } else {
      setTimeout(() => setActiveSignal(null), 5000);
    }
  };

  const runJumpSequence = () => {
    if ('vibrate' in navigator) navigator.vibrate(1000);
    let step = 1;
    setJumpStep(step);
    const interval = setInterval(() => {
      step++;
      if (step > 5) {
        clearInterval(interval);
        setJumpStep(0);
        setActiveSignal(null);
      } else {
        setJumpStep(step);
        if ('vibrate' in navigator) navigator.vibrate([200, 100, 200]);
      }
    }, 3000);
  };

  const runClappingSequence = () => {
    let step = 1;
    setClappingStep(step);
    if ('vibrate' in navigator) navigator.vibrate(200);
    setFlashActive(true);
    setTimeout(() => setFlashActive(false), 200);

    const interval = setInterval(() => {
      step++;
      if (step > 5) {
        clearInterval(interval);
        setClappingStep(0);
        setActiveSignal(null);
      } else {
        setClappingStep(step);
        if ('vibrate' in navigator) navigator.vibrate(200);
        setFlashActive(true);
        setTimeout(() => setFlashActive(false), 200);
      }
    }, 3000);
  };

  const currentLyrics = activeSignal?.type === 'ANTHEM' 
    ? selectedTeam.anthemLyrics 
    : (selectedTeam.songs.find(s => s.id === activeSignal?.songId)?.lyrics || []);

  return (
    <div className={`p-6 flex flex-col items-center min-h-screen transition-all bg-white ${jumpStep > 0 ? 'animate-bounce' : ''}`}>
      {flashActive && <div className="fixed inset-0 z-[100] bg-white animate-pulse" />}
      
      <div className="fixed top-0 left-0 right-0 text-white text-[10px] font-black uppercase tracking-[0.2em] py-3 z-[110] flex items-center justify-center gap-2 shadow-lg" style={{ backgroundColor: CAF_COLORS.green }}>
        <div className="w-2 h-2 bg-white rounded-full animate-ping" />
        DIRECT STADE • {selectedTeam.name.toUpperCase()}
      </div>

      <div className="mt-16 w-full flex justify-between items-end mb-10 px-2">
        <div className="flex flex-col">
          <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Temps Match</span>
          <span className="text-4xl font-black italic" style={{ color: CAF_COLORS.maroon }}>{matchMinute}'</span>
        </div>
        <div className="text-right">
          <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Signal</span>
          <span className="block text-xs font-bold uppercase text-green-600">Connecté</span>
        </div>
      </div>

      <div className="flex-1 w-full flex flex-col items-center justify-center relative">
        {countdown !== null ? (
          <div className="text-center animate-fade-in">
            <span className="text-[10px] font-black uppercase tracking-[0.3em] text-slate-400 mb-4 block">Action dans...</span>
            <div className="text-[12rem] font-black leading-none italic mb-4" style={{ color: CAF_COLORS.maroon }}>{countdown}</div>
            <p className="text-xl font-black uppercase tracking-tighter text-slate-800 animate-pulse">{activeSignal?.message}</p>
          </div>
        ) : activeSignal ? (
          <div className="w-full text-center animate-fade-in">
            <div className="bg-slate-50 p-10 rounded-[4rem] border-2 border-slate-100 shadow-2xl relative overflow-hidden">
              <h2 className="text-4xl font-black uppercase italic mb-8 leading-tight" style={{ color: CAF_COLORS.maroon }}>{activeSignal.message}</h2>
              
              {jumpStep > 0 && (
                <div className="flex flex-col items-center gap-6 py-8">
                   <div className="text-9xl animate-bounce">👟</div>
                   <div className="text-center">
                      <p className="text-3xl font-black uppercase italic text-red-600 mb-2">OLÉ OLÉ OLÉ!</p>
                      <span className="text-6xl font-black" style={{ color: CAF_COLORS.green }}>{jumpStep} / 5</span>
                      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-4">TOUT LE MONDE SAUTE !</p>
                   </div>
                </div>
              )}

              {clappingStep > 0 && (
                <div className="flex flex-col items-center gap-8 py-10">
                   <div className="flex justify-center gap-10">
                      <span className={`text-8xl transition-transform ${flashActive ? 'scale-125' : 'scale-100'}`}>🙌</span>
                   </div>
                   <div className="text-center">
                      <span className="text-6xl font-black" style={{ color: CAF_COLORS.green }}>{clappingStep} / 5</span>
                      <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mt-2">MAINS EN L'AIR... CLAP !</p>
                   </div>
                </div>
              )}

              {(activeSignal.type === 'SONG' || activeSignal.type === 'ANTHEM') && !jumpStep && !clappingStep && (
                <div className="space-y-6">
                  <div className="w-16 h-1 bg-slate-200 mx-auto rounded-full mb-8" />
                  <p className="text-3xl font-black italic leading-snug text-[#2D2D2D]">
                    "{currentLyrics[activeLyricsIndex] || '...'}"
                  </p>
                </div>
              )}
            </div>
          </div>
        ) : (
          <div className="text-center opacity-40">
            <div className="w-24 h-24 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-6 shadow-inner">🏟️</div>
            <h3 className="text-lg font-black uppercase italic tracking-tighter">Vibrer avec le stade</h3>
          </div>
        )}
      </div>

      <div className="w-full mt-8 mb-32 bg-slate-50 p-6 rounded-[2.5rem] border border-slate-100 shadow-sm">
         <h4 className="text-[9px] font-black uppercase tracking-widest text-slate-400 mb-4">Programme de synchronisation</h4>
         <div className="space-y-3">
            <div className={`flex justify-between items-center p-3 rounded-xl ${matchMinute < 10 ? 'bg-white border' : 'opacity-30'}`}>
               <span className="text-[10px] font-black uppercase tracking-tight">10' - Sir! Sir! Sir!</span>
               <span className="text-[8px] font-bold text-slate-400">SONG</span>
            </div>
            <div className={`flex justify-between items-center p-3 rounded-xl ${matchMinute < 12 ? 'bg-white border' : 'opacity-30'}`}>
               <span className="text-[10px] font-black uppercase tracking-tight">12' - Al Hkaya (Arabic)</span>
               <span className="text-[8px] font-bold text-slate-400">LYRICS</span>
            </div>
            <div className={`flex justify-between items-center p-3 rounded-xl ${matchMinute < 20 ? 'bg-white border border-red-100 shadow-sm' : 'opacity-30'}`}>
               <span className="text-[10px] font-black uppercase tracking-tight text-red-600">20' - Saut & Olé (5x)</span>
            </div>
         </div>
      </div>
    </div>
  );
};

export default LiveConductor;
