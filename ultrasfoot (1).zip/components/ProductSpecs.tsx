
import React from 'react';
import { APP_MODULES } from '../constants';

const ProductSpecs: React.FC = () => {
  return (
    <div className="p-6 overflow-y-auto max-h-screen">
      <h2 className="text-3xl font-black uppercase tracking-tighter mb-2">Spécifications</h2>
      <p className="text-slate-400 mb-8 font-medium">L'innovation technologique au service de la passion.</p>

      <section className="mb-10">
        <h3 className="text-lg font-bold text-blue-400 uppercase mb-4 tracking-widest">Le Challenge : Réseau Saturé</h3>
        <div className="space-y-4">
            <div className="bg-slate-800 p-5 rounded-2xl border border-slate-700">
                <h4 className="font-bold text-white mb-1">Architecture "Ultra-Light"</h4>
                <p className="text-sm text-slate-400">Le contenu lourd (audio, images, paroles) est pré-chargé en cache lors de l'installation. Dans le stade, seul un signal binaire de 1 octet est envoyé via WebSocket pour le déclenchement.</p>
            </div>
            <div className="bg-slate-800 p-5 rounded-2xl border border-slate-700">
                <h4 className="font-bold text-white mb-1">Local Sync (NTP Protocol)</h4>
                <p className="text-sm text-slate-400">Les téléphones synchronisent leur horloge interne avec le serveur dès l'entrée au stade. Le signal de déclenchement inclut un timestamp futur (ex: T+2000ms) pour que tout le monde vibre au même instant précis.</p>
            </div>
            <div className="bg-slate-800 p-5 rounded-2xl border border-slate-700">
                <h4 className="font-bold text-white mb-1">Bluetooth Mesh Backup</h4>
                <p className="text-sm text-slate-400">Si la 5G tombe, les téléphones créent un réseau maillé local pour se transmettre les signaux de proche en proche sans internet.</p>
            </div>
        </div>
      </section>

      <section className="mb-10">
        <h3 className="text-lg font-bold text-green-400 uppercase mb-4 tracking-widest">Modules de l'App</h3>
        <div className="grid grid-cols-1 gap-3">
          {APP_MODULES.map(m => (
            <div key={m.id} className="p-4 bg-slate-800/50 rounded-xl border border-slate-700 flex items-start gap-4">
                <div className="w-10 h-10 bg-slate-700 rounded-lg flex items-center justify-center shrink-0">
                    <span className="text-xl">🛠️</span>
                </div>
                <div>
                    <h5 className="font-bold text-white">{m.name}</h5>
                    <p className="text-xs text-slate-400">{m.description}</p>
                    <span className="text-[10px] text-slate-500 font-mono mt-1 block">CODE_NAME: {m.id.toUpperCase()}</span>
                </div>
            </div>
          ))}
        </div>
      </section>

      <section className="mb-10">
        <h3 className="text-lg font-bold text-orange-400 uppercase mb-4 tracking-widest">Monétisation</h3>
        <div className="bg-gradient-to-r from-orange-500/20 to-yellow-500/20 p-5 rounded-2xl border border-orange-500/30">
            <ul className="space-y-3 text-sm">
                <li className="flex gap-2">✅ <span className="text-slate-300"><b>Partenariat CAF :</b> Officialisation comme "Compagnon de Match"</span></li>
                <li className="flex gap-2">✅ <span className="text-slate-300"><b>Sponsoring Flash :</b> "Ce but vous est offert par [Sponsor]" avec logo sur écran de flash.</span></li>
                <li className="flex gap-2">✅ <span className="text-slate-300"><b>Premium Fans :</b> Badges NFC physiques liés à l'app pour accès aux zones VIP.</span></li>
            </ul>
        </div>
      </section>
    </div>
  );
};

export default ProductSpecs;
