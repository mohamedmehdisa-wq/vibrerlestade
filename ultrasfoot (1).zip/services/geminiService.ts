
import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const STORAGE_KEY = 'vibrer_stade_chants_cache';

const getCachedChants = (country: string): string[] | null => {
  const cache = localStorage.getItem(STORAGE_KEY);
  if (!cache) return null;
  const parsedCache = JSON.parse(cache);
  return parsedCache[country] || null;
};

const setCachedChants = (country: string, lyrics: string[]) => {
  const cache = localStorage.getItem(STORAGE_KEY);
  const parsedCache = cache ? JSON.parse(cache) : {};
  parsedCache[country] = lyrics;
  localStorage.setItem(STORAGE_KEY, JSON.stringify(parsedCache));
};

export const generateChantLyrics = async (country: string) => {
  // Vérifier le cache d'abord (très important en mode stade)
  const cached = getCachedChants(country);
  if (cached && !navigator.onLine) {
    console.log(`Utilisation du cache hors-ligne pour ${country}`);
    return cached;
  }

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Génère 3 lignes de chant de supporter passionné pour l'équipe nationale de football du ${country} pour la CAN 2025. Utilise des mots locaux et de l'énergie.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            lyrics: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            }
          }
        }
      }
    });
    
    const lyrics = JSON.parse(response.text).lyrics;
    setCachedChants(country, lyrics); // Mettre à jour le cache
    return lyrics;
  } catch (error) {
    console.error("Gemini Error:", error);
    // Fallback sur le cache si disponible, sinon défaut
    return cached || ["Allez, allez!", "Tous ensemble pour la victoire!", "Vibrez le stade!"];
  }
};
