
import React, { useState, useEffect } from 'react';
import { AppSection, Team, Match, SyncSignal } from './types';
import { TEAMS, MATCHES, COMPETITIONS, CAF_COLORS } from './constants';
import Layout from './components/Layout';
import LiveConductor from './components/LiveConductor';

const liveChannel = new BroadcastChannel('stadium_sync');

const App: React.FC = () => {
  const [section, setSection] = useState<AppSection>(AppSection.HOME);
  const [selectedTeam, setSelectedTeam] = useState<Team | null>(null);
  const [selectedMatch, setSelectedMatch] = useState<Match | null>(null);
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState(false);
  const [currentLiveSignal, setCurrentLiveSignal] = useState<SyncSignal | null>(null);

  useEffect(() => {
    liveChannel.onmessage = (event) => {
      const signal: SyncSignal = event.data;
      setCurrentLiveSignal(signal);
      // Auto-switch to live if a signal comes and we have a team selected
      if (section !== AppSection.ADMIN && section !== AppSection.LIVE && selectedTeam) {
        setSection(AppSection.LIVE);
      }
    };
  }, [section, selectedTeam]);

  const handleSelectTeam = (team: Team) => {
    setSelectedTeam(team);
    setSection(AppSection.HOME);
    setSelectedMatch(null); 
  };

  const handleMatchClick = (match: Match) => {
    setSelectedMatch(match);
  };

  const enterLiveFromMatch = (teamId: string) => {
    const team = TEAMS.find(t => t.id === teamId);
    if (team) {
      setSelectedTeam(team);
      setSection(AppSection.LIVE);
      setSelectedMatch(null);
    }
  };

  const publishSignal = (type: SyncSignal['type'], message: string, songId?: string) => {
    const signal: SyncSignal = {
      id: Math.random().toString(36).substr(2, 9),
      timestamp: Date.now(),
      message,
      type,
      songId
    };
    liveChannel.postMessage(signal);
    setCurrentLiveSignal(signal);
  };

  const renderAdmin = () => (
    <div className="p-8 animate-fade-in bg-white min-h-screen">
       {!isAdminAuthenticated ? (
          <div className="flex flex-col items-center justify-center min-h-[70vh] text-center">
             <div className="w-24 h-24 bg-slate-50 rounded-3xl flex items-center justify-center mb-8 shadow-inner border border-slate-100 text-3xl"> 🏟️ </div>
             <h2 className="text-3xl font-black uppercase mb-4 italic tracking-tighter" style={{ color: CAF_COLORS.maroon }}>Staff Stadium</h2>
             <button onClick={() => setIsAdminAuthenticated(true)} className="text-white px-12 py-5 rounded-[2rem] font-black uppercase text-xs tracking-[0.2em] shadow-2xl" style={{ backgroundColor: CAF_COLORS.maroon }}>Accéder au Panel</button>
          </div>
       ) : (
          <div className="space-y-10 pb-20">
             <div className="flex justify-between items-center">
               <h2 className="text-3xl font-black uppercase italic tracking-tighter">Director Panel</h2>
               <button onClick={() => setIsAdminAuthenticated(false)} className="text-[10px] font-black text-red-600 uppercase">Fermer</button>
             </div>

             <section className="bg-black text-white p-8 rounded-[3rem] shadow-xl">
                <span className="text-[10px] font-black uppercase opacity-60 block mb-2">Contrôle de Masse</span>
                <span className="text-xl font-black italic">SYNC ACTIVE : {selectedTeam?.name.toUpperCase() || 'AUCUNE'}</span>
             </section>

             <section className="space-y-6">
                <h3 className="text-xs font-black uppercase text-slate-400 tracking-widest">Séquences Synchronisées</h3>
                <div className="grid grid-cols-2 gap-4">
                   <button onClick={() => publishSignal('JUMP', 'TOUT LE MONDE SAUTE !', 'ma_ole')} className="bg-[#008B51] text-white p-8 rounded-[2.5rem] flex flex-col items-center gap-3 active:scale-95 transition-all shadow-xl col-span-2">
                      <span className="text-4xl">👟</span>
                      <span className="text-[10px] font-black uppercase tracking-widest">SAUT & OLÉ (5X)</span>
                   </button>
                   <button onClick={() => publishSignal('CLAPPING', 'CLAPPING VIKING (5X)')} className="bg-slate-100 border-2 border-slate-200 p-8 rounded-[2.5rem] flex flex-col items-center gap-3 active:bg-[#7B161D] active:text-white transition-all shadow-xl">
                      <span className="text-4xl">🙌</span>
                      <span className="text-[10px] font-black uppercase">CLAPPING 5X</span>
                   </button>
                   <button onClick={() => publishSignal('SONG', 'AL HKAYA (ARABIC)', 'ma_hkayat')} className="bg-slate-100 border-2 border-slate-200 p-8 rounded-[2.5rem] flex flex-col items-center gap-3 active:bg-[#7B161D] active:text-white transition-all shadow-xl text-center">
                      <span className="text-4xl">🎼</span>
                      <span className="text-[10px] font-black uppercase">CHANT ARABE</span>
                   </button>
                   <button onClick={() => publishSignal('SONG', 'SIR! SIR! SIR!', 'ma_sir')} className="bg-[#7B161D] text-white p-8 rounded-[2.5rem] flex flex-col items-center gap-3 shadow-xl col-span-2">
                      <span className="text-4xl">🦁</span>
                      <span className="text-[10px] font-black uppercase tracking-widest">LANCER SIR! SIR! SIR!</span>
                   </button>
                </div>
             </section>
          </div>
       )}
    </div>
  );

  return (
    <Layout activeSection={section} onNavigate={setSection}>
      {section === AppSection.HOME && (
        <div className="animate-fade-in flex flex-col items-center">
          <div className="w-full pt-12 pb-24 px-6 text-center rounded-b-[4rem] shadow-xl relative overflow-hidden" style={{ backgroundColor: CAF_COLORS.maroon }}>
            <h1 className="text-3xl font-black text-white uppercase italic tracking-tighter mb-4">VIBRER LE STADE</h1>
            <div className="bg-white/10 p-6 rounded-[2rem] backdrop-blur-md flex justify-between items-center border border-white/10">
              <div className="text-left">
                <span className="text-[8px] font-black text-white/50 uppercase tracking-widest block">Ma Nation</span>
                <span className="text-white font-black">{selectedTeam ? `${selectedTeam.flag} ${selectedTeam.name}` : 'CHOISIR ÉQUIPE'}</span>
              </div>
              <button onClick={() => setSection(AppSection.HUB)} className="bg-white text-[#7B161D] px-4 py-2 rounded-full text-[9px] font-black uppercase shadow-lg">Changer</button>
            </div>
          </div>
          <div className="w-full px-8 -mt-10 z-20 space-y-6">
             <button onClick={() => setSection(AppSection.LIVE)} className="w-full bg-white border-4 border-[#7B161D] p-10 rounded-[4rem] shadow-2xl flex flex-col items-center gap-4 transition-transform active:scale-95">
                <span className="text-4xl animate-pulse">🏟️</span>
                <span className="text-xl font-black uppercase italic text-[#7B161D]">Entrer dans le stade</span>
                <p className="text-[9px] font-bold text-slate-300 uppercase tracking-widest">Synchronisation Directe</p>
             </button>
             {selectedTeam && (
               <button onClick={() => setSection(AppSection.PREP)} className="w-full bg-[#008B51] text-white p-6 rounded-[2.5rem] shadow-xl flex items-center justify-between group active:scale-95 transition-all">
                 <span className="text-lg font-black uppercase italic">Bibliothèque Chants</span>
                 <span className="text-2xl">🎵</span>
               </button>
             )}
             
             <div className="pt-10 flex flex-col items-center opacity-40">
               <span className="text-[8px] font-black uppercase tracking-[0.3em] mb-4 text-slate-500">Bientôt sur Stores Officiels</span>
               <div className="flex gap-6">
                 {/* App Store Logo */}
                 <div className="flex flex-col items-center gap-1">
                   <div className="w-12 h-12 bg-black rounded-xl flex items-center justify-center shadow-lg transform transition-transform active:scale-90">
                     <svg className="w-7 h-7 text-white" viewBox="0 0 384 512" fill="currentColor">
                       <path d="M318.7 268.7c-.2-36.7 16.4-64.4 50-84.8-18.8-26.9-47.2-41.7-84.7-44.6-35.5-2.8-74.3 21.8-88.5 21.8-11.4 0-51.1-20.8-83.6-20.1-42.9.6-82.7 25.1-104.5 63.3-44.6 77.5-11.4 191.8 31.5 254.1 21.1 30.4 46.3 64.5 79.4 63.3 32.1-1.2 44.3-21.4 83.1-21.4 38.6 0 50.1 21.4 83.7 20.8 33.6-.6 55.4-30.7 75.6-60.5 23.3-34 32.9-66.9 33.4-68.6-.8-.3-65.5-25.2-65.4-100.3zM285.4 97.4c17.5-21.1 29.5-50.7 26.3-80.1-25.4 1-56 16.8-74.2 38.2-16.3 19.1-30.6 48.7-26.8 77.2 28.2 2.2 57.2-14.2 74.7-35.3z" />
                     </svg>
                   </div>
                   <span className="text-[6px] font-black uppercase tracking-tighter">App Store</span>
                 </div>
                 
                 {/* Google Play Logo */}
                 <div className="flex flex-col items-center gap-1">
                   <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center shadow-lg border border-slate-100 transform transition-transform active:scale-90">
                     <svg className="w-7 h-7" viewBox="0 0 512 512" fill="none">
                       <path d="M72.06 18.2C62.43 27.65 57 41.28 57 57.17V454.8c0 15.9 5.43 29.5 15.06 38.97l1.72 1.57L300.9 268.2v-5.2L73.78 16.63l-1.72 1.57z" fill="#00A1E9"/>
                       <path d="M381.8 349l-80.9-80.8v-5.2l80.9-80.8 1.9 1.1 95.8 54.4c27.4 15.5 27.4 41.1 0 56.7l-95.8 54.4-1.9 0.2z" fill="#FFC900"/>
                       <path d="M383.7 349.2l-82.8-82.8-228.8 227.4c9.1 8.8 24.1 9.9 41 0.3l270.6-153.8-0.1 8.9z" fill="#E41E26"/>
                       <path d="M383.7 162.8l-270.6-153.8c-16.9-9.6-31.9-8.5-41 0.3l228.8 227.4 82.8-82.8v8.9z" fill="#00A151"/>
                     </svg>
                   </div>
                   <span className="text-[6px] font-black uppercase tracking-tighter">Google Play</span>
                 </div>
               </div>
             </div>
          </div>
        </div>
      )}
      {section === AppSection.HUB && (
        <div className="p-8 animate-fade-in bg-white min-h-screen">
          <h2 className="text-3xl font-black uppercase italic mb-10 tracking-tighter">Nations Qualifiées</h2>
          <div className="grid grid-cols-1 gap-4 overflow-y-auto no-scrollbar max-h-[75vh]">
            {TEAMS.map(team => (
              <button key={team.id} onClick={() => handleSelectTeam(team)} className={`p-6 rounded-[2.5rem] border-2 transition-all flex items-center justify-between ${selectedTeam?.id === team.id ? 'border-transparent shadow-2xl text-white bg-[#7B161D]' : 'bg-white border-slate-50 text-slate-800 shadow-sm'}`}>
                <div className="flex items-center gap-5">
                   <span className="text-4xl">{team.flag}</span>
                   <div className="text-left">
                      <span className="block font-black text-lg uppercase tracking-tighter">{team.name}</span>
                      <span className={`text-[9px] font-bold uppercase ${selectedTeam?.id === team.id ? 'text-white/60' : 'text-slate-400'}`}>Groupe {team.group}</span>
                   </div>
                </div>
              </button>
            ))}
          </div>
        </div>
      )}
      {section === AppSection.PREP && (
        <div className="p-8 animate-fade-in bg-white min-h-screen">
           <h2 className="text-3xl font-black uppercase italic tracking-tighter mb-10">Chants {selectedTeam?.name}</h2>
           <div className="space-y-6">
              {selectedTeam?.songs.map(song => (
                <div key={song.id} className="bg-slate-50 p-6 rounded-[2.5rem] border border-slate-100 shadow-sm">
                   <h3 className="font-black uppercase italic text-lg mb-4 text-[#2D2D2D]">{song.title}</h3>
                   <div className="bg-white p-6 rounded-2xl mb-4 border border-slate-200">
                      {song.lyrics.map((l, i) => <p key={i} className="text-sm font-black text-[#7B161D] uppercase mb-1">"{l}"</p>)}
                   </div>
                </div>
              ))}
              {(!selectedTeam?.songs || selectedTeam.songs.length === 0) && (
                 <div className="text-center py-20 opacity-40">
                    <p className="font-black uppercase italic text-sm tracking-widest">Chargement des chants du pays...</p>
                 </div>
              )}
           </div>
        </div>
      )}
      {section === AppSection.ADMIN && renderAdmin()}
      {section === AppSection.LIVE && selectedTeam && <LiveConductor selectedTeam={selectedTeam} externalSignal={currentLiveSignal} />}
      {section === AppSection.MATCHES && (
        <div className="p-8 animate-fade-in bg-white min-h-screen relative">
          <div className="flex justify-between items-center mb-10">
            <h2 className="text-3xl font-black uppercase italic tracking-tighter">Calendrier</h2>
            <div className="bg-slate-100 px-4 py-2 rounded-full">
              <span className="text-[10px] font-black text-slate-400 uppercase">CAN 2025</span>
            </div>
          </div>
          
          <div className="space-y-6 pb-32 overflow-y-auto no-scrollbar max-h-[78vh]">
            {MATCHES.map((match) => {
              const homeTeam = TEAMS.find(t => t.id === match.homeTeamId);
              const awayTeam = TEAMS.find(t => t.id === match.awayTeamId);
              const isFinished = match.status === 'FINISHED' || (match.homeScore !== undefined && match.awayScore !== undefined);
              
              return (
                <div 
                  key={match.id} 
                  onClick={() => handleMatchClick(match)}
                  className="bg-slate-50 p-6 rounded-[3rem] border border-slate-100 shadow-sm active:scale-[0.98] transition-all cursor-pointer hover:bg-white hover:shadow-xl"
                >
                  <div className="flex justify-between items-center mb-6">
                    <span className="text-[10px] font-black uppercase text-slate-400 tracking-widest">{match.date} • {match.time}</span>
                    <div className="flex gap-2">
                       {!isFinished && <span className="bg-green-100 text-green-700 text-[8px] font-black px-2 py-1 rounded-full uppercase animate-pulse">Vibrer</span>}
                       <span className={`text-[9px] font-black px-3 py-1 rounded-full uppercase ${isFinished ? 'bg-slate-200 text-slate-500' : 'bg-red-100 text-[#7B161D]'}`}>
                         {isFinished ? 'Terminé' : `Groupe ${match.group || '-'}`}
                       </span>
                    </div>
                  </div>
                  <div className="flex justify-between items-center px-2">
                    <div className="flex flex-col items-center gap-2 w-1/3">
                      <span className="text-5xl">{homeTeam?.flag || '🏁'}</span>
                      <span className="text-[10px] font-black uppercase text-center truncate w-full">{homeTeam?.name || '...'}</span>
                    </div>
                    <div className="flex flex-col items-center">
                      {isFinished ? (
                        <div className="flex items-center gap-4 text-3xl font-black italic">
                          <span>{match.homeScore}</span>
                          <span className="text-slate-300">-</span>
                          <span>{match.awayScore}</span>
                        </div>
                      ) : (
                        <span className="text-2xl font-black italic text-slate-300">VS</span>
                      )}
                    </div>
                    <div className="flex flex-col items-center gap-2 w-1/3">
                      <span className="text-5xl">{awayTeam?.flag || '🏁'}</span>
                      <span className="text-[10px] font-black uppercase text-center truncate w-full">{awayTeam?.name || '...'}</span>
                    </div>
                  </div>
                  <div className="mt-8 pt-4 border-t border-slate-200/50 flex flex-col items-center gap-1">
                    <p className="text-[9px] font-bold text-slate-400 uppercase tracking-tighter">🏟️ {match.stadium}</p>
                    <span className="text-[8px] font-black text-[#7B161D] uppercase">Tapez pour rejoindre le live</span>
                  </div>
                </div>
              );
            })}
          </div>

          {selectedMatch && (
            <div className="fixed inset-0 z-[200] bg-black/80 backdrop-blur-md flex items-end justify-center animate-fade-in" onClick={() => setSelectedMatch(null)}>
              <div className="bg-white w-full rounded-t-[4rem] p-10 shadow-2xl animate-fade-in" style={{ animationDuration: '0.3s' }} onClick={e => e.stopPropagation()}>
                <div className="w-16 h-1.5 bg-slate-200 rounded-full mx-auto mb-10" />
                <h3 className="text-2xl font-black uppercase italic tracking-tighter text-center mb-4">Rejoindre le Stade</h3>
                <p className="text-center text-[10px] font-bold text-slate-400 uppercase tracking-[0.2em] mb-10">Choisissez votre camp pour vibrer</p>
                
                <div className="grid grid-cols-2 gap-6">
                   <button 
                     onClick={() => enterLiveFromMatch(selectedMatch.homeTeamId)}
                     className="flex flex-col items-center gap-4 p-8 bg-slate-50 rounded-[3rem] border-4 border-transparent active:border-[#7B161D] transition-all shadow-sm hover:shadow-lg hover:bg-slate-100"
                   >
                     <span className="text-7xl">{TEAMS.find(t => t.id === selectedMatch.homeTeamId)?.flag}</span>
                     <span className="font-black uppercase text-[10px] text-center">{TEAMS.find(t => t.id === selectedMatch.homeTeamId)?.name}</span>
                     <span className="text-[8px] font-black text-green-600 uppercase">DIRECT</span>
                   </button>
                   
                   <button 
                     onClick={() => enterLiveFromMatch(selectedMatch.awayTeamId)}
                     className="flex flex-col items-center gap-4 p-8 bg-slate-50 rounded-[3rem] border-4 border-transparent active:border-[#7B161D] transition-all shadow-sm hover:shadow-lg hover:bg-slate-100"
                   >
                     <span className="text-7xl">{TEAMS.find(t => t.id === selectedMatch.awayTeamId)?.flag}</span>
                     <span className="font-black uppercase text-[10px] text-center">{TEAMS.find(t => t.id === selectedMatch.awayTeamId)?.name}</span>
                     <span className="text-[8px] font-black text-green-600 uppercase">DIRECT</span>
                   </button>
                </div>

                <button 
                  onClick={() => setSelectedMatch(null)}
                  className="w-full mt-10 py-5 text-slate-300 font-black uppercase text-[10px] tracking-widest active:text-red-600"
                >
                  Fermer
                </button>
              </div>
            </div>
          )}
        </div>
      )}
    </Layout>
  );
};

export default App;
